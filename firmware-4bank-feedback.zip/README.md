# LumaFader 四頁版 — 2026-10-07

白：Faders CC16–19；Buttons（下到上）CC20、21、22、23。
紅：Faders CC12–15；Buttons（下到上）CC27、26、25、24。
黃：Faders CC28–31；Buttons（下到上）CC32、33、34、35。
綠：Faders CC36–39；Buttons（下到上）CC40、41、42、43。
以上預設皆為 MIDI Channel 1。

按住最下鍵再按最上鍵：下一頁；按住最上鍵再按最下鍵：上一頁。
頁面到白／綠的邊界不循環。第二鍵按下即切換，可維持按住第一鍵連續切頁。
單鍵長按不切換 bank，放開仍發送原有 CC127→CC0 pulse。
組合鍵的放開不送 button MIDI。四個按鈕以當前頁色顯示。

保留 MIDI feedback、pickup、Jump Mode 與錄製操作；錄製的 CC sets 改成四頁。
裝置 MIDI learn 改對應當前頁的 fader，不再指向隱藏的 global bank。
settings.json 每頁只有一列，保留既有 key 名稱以相容 serial protocol。

離線 editor 原位置：/Users/admin/Documents/LumaFader_web/index.html。
editor.html 為同版本副本。未連線可預覽預設配置；連線後讀取裝置實際設定。
修改設定後 SAVE TO HARDWARE，依原 serial protocol 必須重新啟動裝置才套用。
請在 Chrome/Edge 使用原本的 Web Serial 連線方式。

backup/ 包含本次修改前的裝置檔案及 editor-original.html。
若要復原，將 backup 中對應 .py、settings.json、version.txt 複製回裝置，code.py 最後複製；editor-original.html 複製回原 index.html。

驗證：Python 語法、真實設定載入、唯一 CC、單鍵長按、雙向切頁、連續切頁、邊界、組合鍵不送 MIDI、channel 解析、錄製四頁；JS 語法與四頁 rendering（mock DOM）。
仍需實機確認按鍵、音訊軟體 MIDI 接收、UA 回傳燈號；未以實際瀏覽器驗證 editor 外觀／Web Serial。
